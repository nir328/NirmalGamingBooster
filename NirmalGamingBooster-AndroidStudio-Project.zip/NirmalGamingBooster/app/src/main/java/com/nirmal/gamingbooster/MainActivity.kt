package com.nirmal.gamingbooster

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.view.Display
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.io.File
import java.util.Locale

private val Bg = Color(0xFF080B12)
private val Panel = Color(0xFF141B27)
private val Accent = Color(0xFF61F2B1)
private val Muted = Color(0xFF9AA8BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 11, 18)
        window.navigationBarColor = android.graphics.Color.rgb(8, 11, 18)
        setContent { BoosterApp() }
    }
}

private enum class Page { HOME, DISPLAY, GAMING, SYSTEM, SETTINGS }

@Composable
private fun BoosterApp() {
    var page by remember { mutableStateOf(Page.HOME) }
    var profile by remember { mutableStateOf("Balanced") }
    val context = LocalContext.current
    val activity = context as Activity
    var currentHz by remember { mutableFloatStateOf(activity.display?.refreshRate ?: 0f) }
    var thermal by remember { mutableStateOf("Checking…") }
    var ram by remember { mutableStateOf("Reading…") }
    var cpu by remember { mutableStateOf("Unavailable") }
    var cpuGov by remember { mutableStateOf("Unavailable") }
    var gpu by remember { mutableStateOf("Unavailable") }
    var gpuGov by remember { mutableStateOf("Unavailable") }
    var ffInstalled by remember { mutableStateOf(false) }
    var rootState by remember { mutableStateOf("Not verified") }
    var note by remember { mutableStateOf("Choose a supported display mode to request it.") }

    fun updateStats() {
        currentHz = activity.windowManager.defaultDisplay.refreshRate
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        thermal = if (Build.VERSION.SDK_INT >= 29) {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                else -> "Unknown"
            }
        } else "Not exposed by this Android version"
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        ram = "${((mi.totalMem - mi.availMem) / 1024 / 1024)} MB used / ${mi.totalMem / 1024 / 1024} MB total"
        cpu = readFirst(listOf("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"))?.let { "${it.toLongOrNull()?.div(1000) ?: it} MHz (CPU0)" } ?: "Unavailable to this app"
        cpuGov = readFirst(listOf("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")) ?: "Unavailable to this app"
        val gpuNode = File("/sys/class/devfreq").listFiles()?.firstOrNull { File(it, "cur_freq").canRead() }
        gpu = (gpuNode?.let { readFirst(listOf(File(it, "cur_freq").absolutePath)) } ?: readFirst(listOf("/sys/class/kgsl/kgsl-3d0/gpuclk")))?.let { raw -> "${raw.toLongOrNull()?.div(1000000) ?: raw} MHz" } ?: "Unavailable to this app"
        gpuGov = gpuNode?.let { readFirst(listOf(File(it, "governor").absolutePath)) } ?: "Unavailable to this app"
        ffInstalled = packageExists(context, "com.dts.freefiremax")
        rootState = if (listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/data/adb/ksu").any { File(it).exists() }) "su / KernelSU marker detected (not authenticated)" else "No accessible root marker detected"
    }
    LaunchedEffect(Unit) { while (true) { updateStats(); delay(1500) } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                val items = listOf(Page.HOME to Icons.Default.Dashboard, Page.DISPLAY to Icons.Default.DisplaySettings, Page.GAMING to Icons.Default.SportsEsports, Page.SYSTEM to Icons.Default.Memory, Page.SETTINGS to Icons.Default.Settings)
                items.forEach { (p, icon) -> NavigationBarItem(selected = page == p, onClick = { page = p }, icon = { Icon(icon, null) }, label = { Text(p.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, indicatorColor = Accent.copy(alpha = .13f), selectedTextColor = Accent, unselectedIconColor = Muted, unselectedTextColor = Muted)) }
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp)) {
                item { Header() }
                when (page) {
                    Page.HOME -> {
                        item { HeroCard(currentHz, profile) }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("THERMAL", thermal, Modifier.weight(1f)); StatCard("RAM", ram.substringBefore(" / "), Modifier.weight(1f)) } }
                        item { SectionTitle("QUICK PROFILES") }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Battery", "Balanced", "Gaming").forEach { p -> FilterChip(selected = profile == p, onClick = { profile = p }, label = { Text(p) }) } } }
                        item { InfoCard("HONEST PERFORMANCE", "This app reports measurements and requests Android-supported display settings. Profile labels organize the dashboard; they do not change CPU/GPU governors or promise extra FPS.") }
                    }
                    Page.DISPLAY -> {
                        item { SectionTitle("DISPLAY REFRESH RATE") }
                        item { InfoCard("LIVE DISPLAY", "Reported by Android: ${String.format(Locale.US, "%.1f", currentHz)} Hz", "The current app display mode; the system may change it later.") }
                        val modes = activity.windowManager.defaultDisplay.supportedModes?.map { it.refreshRate }.orEmpty().map { it.toInt() }.distinct().sorted()
                        item { Text("Available modes: ${if (modes.isEmpty()) "Not reported" else modes.joinToString(" / ") { "$it Hz" }}", color = Muted) }
                        item { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { listOf(60, 90, 120, 144).forEach { hz -> val supported = modes.any { it == hz || kotlin.math.abs(it - hz) <= 1 }; Button(onClick = { val mode = activity.windowManager.defaultDisplay.supportedModes?.minByOrNull { kotlin.math.abs(it.refreshRate - hz) }; if (mode == null || kotlin.math.abs(mode.refreshRate - hz) > 1f) note = "$hz Hz is not reported as a supported display mode." else { val attrs = activity.window.attributes; attrs.preferredDisplayModeId = mode.modeId; activity.window.attributes = attrs; note = "Requested ${mode.refreshRate} Hz. Verify the live reading; Android/XOS may override it." } }, enabled = supported, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (supported) Panel else Panel.copy(alpha = .5f), contentColor = Accent)) { Text("${hz} Hz  ${if (supported) "· request mode" else "· not exposed"}") } } } }
                        item { InfoCard("STATUS", note) }
                        item { InfoCard("IMPORTANT", "90 Hz or 144 Hz in the panel does not mean Free Fire MAX renders at that FPS. The game, firmware, thermal state and display policy all matter.") }
                    }
                    Page.GAMING -> {
                        item { SectionTitle("FREE FIRE MAX CENTER") }
                        item { InfoCard("GAME DETECTION", if (ffInstalled) "Free Fire MAX package detected" else "Free Fire MAX not detected", "Detection uses the installed package list. No game files are modified.") }
                        item { Button(onClick = { profile = "Gaming"; page = Page.DISPLAY }, modifier = Modifier.fillMaxWidth()) { Text("Set dashboard profile to Gaming") } }
                        item { StatCard("FPS / FRAME TIME", "Not available", Modifier.fillMaxWidth()) }
                        item { InfoCard("WHY?", "Reliable per-game FPS and frame-time telemetry is not exposed to ordinary third-party apps on every XOS build. No estimated or fabricated FPS is shown.") }
                        item { InfoCard("THERMAL STATE", thermal, "Android PowerManager thermal status") }
                    }
                    Page.SYSTEM -> {
                        item { SectionTitle("SYSTEM TELEMETRY") }
                        item { InfoCard("CPU FREQUENCY", cpu, "CPU governor: $cpuGov · read-only sysfs probe; access depends on kernel permissions.") }
                        item { InfoCard("GPU FREQUENCY", gpu, "GPU governor: $gpuGov · vendor-specific node; unavailable if the kernel blocks access.") }
                        item { InfoCard("MEMORY", ram) }
                        item { InfoCard("THERMAL", thermal) }
                        item { InfoCard("KERNELSU / ROOT", rootState, "This is a marker check only. It does not prove KernelSU is active or request root permission.") }
                        item { InfoCard("SAFETY", "No CPU/GPU overclock, governor write, thermal override, boot-partition change or background cleaner is included.") }
                    }
                    Page.SETTINGS -> {
                        item { SectionTitle("PREFERENCES") }
                        item { Text("Performance profile", color = Muted) }
                        item { listOf("Battery", "Balanced", "Gaming").forEach { p -> Row(Modifier.fillMaxWidth().clickable { profile = p }.background(Panel, RoundedCornerShape(14.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(p, Modifier.weight(1f)); RadioButton(selected = profile == p, onClick = { profile = p }) } } }
                        item { InfoCard("DEVICE", "${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}") }
                        item { InfoCard("PERMISSIONS", "No dangerous runtime permissions are requested. Root is not requested by this build.") }
                    }
                }
            }
        }
    }
}

private fun readFirst(paths: List<String>): String? = paths.firstNotNullOfOrNull { path ->
    try { if (path.contains("*")) null else File(path).takeIf { it.canRead() }?.readText()?.trim()?.takeIf { it.isNotEmpty() } } catch (_: Exception) { null }
}

private fun packageExists(context: Context, pkg: String): Boolean = try {
    if (Build.VERSION.SDK_INT >= 33) context.packageManager.getPackageInfo(pkg, android.content.pm.PackageManager.PackageInfoFlags.of(0)) else @Suppress("DEPRECATION") context.packageManager.getPackageInfo(pkg, 0)
    true
} catch (_: Exception) { false }

@Composable private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text("NIRMAL", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("GAMING BOOSTER  /  EXTREME", color = Accent, fontSize = 10.sp, letterSpacing = 1.5.sp) }
        Surface(color = Accent.copy(alpha = .12f), shape = RoundedCornerShape(50)) { Text("v1.0", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
    }
}
@Composable private fun HeroCard(hz: Float, profile: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("LIVE DISPLAY REFRESH", color = Muted, fontSize = 11.sp, letterSpacing = 1.3.sp)
        Row(verticalAlignment = Alignment.Bottom) { Text(String.format(Locale.US, "%.1f", hz), color = Accent, fontSize = 54.sp, fontWeight = FontWeight.Black); Text(" Hz", color = Muted, modifier = Modifier.padding(bottom = 9.dp)) }
        Text("Active profile: $profile", color = Color.White)
        Text("Measured via Android Display API", color = Muted, fontSize = 11.sp)
    }
}
@Composable private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp); Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2) }
}
@Composable private fun SectionTitle(text: String) { Text(text, color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp) }
@Composable private fun InfoCard(title: String, value: String, detail: String? = null) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        if (detail != null) Text(detail, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}
