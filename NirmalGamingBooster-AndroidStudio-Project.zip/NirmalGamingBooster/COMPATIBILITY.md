# Compatibility report — Infinix Note 50s 5G+ (X6870)

## Publicly documented hardware

- Manufacturer model identifier: X6870.
- MediaTek Dimensity 7300 Ultimate.
- AMOLED display with 60 Hz / 120 Hz / 144 Hz modes listed on the manufacturer product specification page.
- Manufacturer's Note 50s specification advertises 90 FPS gaming; this is not a guarantee of 90 FPS in every game or 144 FPS in Free Fire MAX.

## Software caveat

The device family has Android 16 / XOS 16 firmware reports, but rollout/build availability can differ by region and OTA branch. The app reads the installed Android version at runtime and does not assume a particular XOS 16 build.

## Feature compatibility

| Feature | Assessment |
|---|---|
| Display mode discovery | Supported by Android public API; actual modes depend on firmware |
| Request 60/90/120/144 Hz | Conditional on mode being exposed; OS may override |
| Live refresh-rate display | Supported by Android public API |
| CPU/GPU frequency and governor | Best effort; sysfs permissions/vendor paths may block access |
| Thermal status | Android API 29+; OEM thermal policy remains authoritative |
| RAM use | Supported via ActivityManager |
| Free Fire MAX detection | Package visibility query; package/region may differ |
| Game FPS/frame time | Not implemented; no dependable public API guarantee |
| KernelSU authentication | Not implemented; only a non-authoritative marker check |
| Governor/overclock controls | Not implemented for safety and lack of verified kernel interface |
| Root rollback | Not applicable; app performs no root writes |

## Verification status

**Not device-tested.** No X6870 handset, Android SDK, emulator, or Android build-tools were available in the build environment. The table describes API-level feasibility, not a passed device test.
