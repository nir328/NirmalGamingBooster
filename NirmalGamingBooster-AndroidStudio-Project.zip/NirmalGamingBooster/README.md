# NIRMAL GAMING BOOSTER — EXTREME EDITION

Version: 1.0  
Application ID: `com.nirmal.gamingbooster`  
Language: Kotlin  
UI: Jetpack Compose + Material 3  
Minimum Android: 8.0 (API 26)  
Compile SDK: 35  
Target SDK: 35

## Important build status

This delivery contains the Android Studio project source. It is **not an APK**. The available build environment has Java but no Android SDK, Android build-tools, Gradle installation, emulator, or connected X6870 handset. Therefore an APK could not be compiled, installed, or device-tested here. Do not treat this project as a tested release build.

## Implemented in source

- Premium dark AMOLED dashboard and bottom navigation.
- Live refresh-rate readout using Android `Display.refreshRate`.
- Enumerates `Display.supportedModes` and only enables 60/90/120/144 Hz requests when a matching mode is actually reported.
- Requests the selected mode for this app's window using `preferredDisplayModeId`; Android/XOS may ignore or override it.
- RAM usage via `ActivityManager.MemoryInfo`.
- Android thermal status via `PowerManager` on API 29+.
- Best-effort, read-only CPU frequency and governor probes; reports unavailable if sysfs access is denied.
- Best-effort GPU frequency and governor probes through exposed devfreq/sysfs nodes; reports unavailable when vendor nodes are not exposed.
- Free Fire MAX package detection, without modifying game files.
- Basic root-marker detection. This is not proof that KernelSU is active and does not request root.
- No dangerous runtime permissions, no boot-partition writes, no overclocking, no thermal-limit bypass, no background cleaner/service.

## Explicitly not implemented

- 144 Hz cannot be forced if Android/XOS does not expose or permit the mode.
- 90 Hz is shown only if a corresponding supported display mode is exposed. Some panels expose only 60/120/144.
- No per-game system refresh-rate policy or automatic background switching. Android's public API only lets this app request a mode for its own window; OEM policies and foreground apps remain in control.
- No Free Fire MAX FPS unlock. Game FPS is not reliably available to ordinary third-party apps on all XOS builds. The dashboard deliberately displays “Not available” rather than inventing a value.
- No CPU/GPU governor writes, frequency locks, overclocking, task killing, or root command execution.
- No verified KernelSU API integration. Marker detection is informational only.
- Dashboard profile labels are local UI preferences; they do not modify system performance policy.

## Open and build in Android Studio

1. Install a current Android Studio release with Android SDK Platform 35 and Android SDK Build-Tools 35.x.
2. Extract this project folder.
3. In Android Studio choose **Open** and select the `NirmalGamingBooster` folder.
4. Allow Gradle sync and dependency downloads. Use JDK 17.
5. Connect an Android phone with USB debugging enabled or start an emulator.
6. Select the `app` run configuration and press **Run** to install a debug build.
7. For a release APK, choose **Build → Generate Signed Bundle / APK → APK**, create or select your own signing key, choose the `release` variant, and finish the wizard.
8. Android Studio normally writes the signed APK under `app/release/` (or the output path shown by the wizard).

## Device verification checklist (X6870 / XOS 16)

- Confirm installed Android and XOS build in Settings → My Phone / About phone.
- Install debug APK and confirm launch/navigation.
- Compare the app's live Hz reading with Android's developer refresh-rate overlay, if available.
- Test each enabled refresh mode and confirm the live reading changes; a successful request alone is not proof.
- Check thermal status under normal use; do not stress-test or disable thermal protections.
- Confirm Free Fire MAX package detection on the exact installed regional build.
- Check CPU/GPU readings. “Unavailable” is an expected result when sysfs nodes are restricted.
- Test on the actual 6 GB handset. Emulator results do not establish XOS compatibility.

## Safety and privacy

The app does not collect or transmit data. It has no network permission. It does not request root or change system files. Thermal status and frequency probes are read-only. The display request is limited to this app's own window.
